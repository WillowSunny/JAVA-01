package com.willow.willowservicetestspringbootstarter;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WillowServiceTestSpringBootStarterApplicationTests {

	@Test
	void contextLoads() {
	}

}
