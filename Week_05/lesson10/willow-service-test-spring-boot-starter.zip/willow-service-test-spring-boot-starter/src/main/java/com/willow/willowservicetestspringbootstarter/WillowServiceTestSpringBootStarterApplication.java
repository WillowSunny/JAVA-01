package com.willow.willowservicetestspringbootstarter;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WillowServiceTestSpringBootStarterApplication {

	public static void main(String[] args) {
		SpringApplication.run(WillowServiceTestSpringBootStarterApplication.class, args);
	}

}
