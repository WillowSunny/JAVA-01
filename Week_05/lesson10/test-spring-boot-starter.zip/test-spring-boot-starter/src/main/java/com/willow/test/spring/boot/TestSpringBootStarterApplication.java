package com.willow.test.spring.boot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TestSpringBootStarterApplication {

	public static void main(String[] args) {
		SpringApplication.run(TestSpringBootStarterApplication.class, args);
	}

}
