package com.willow.test.spring.boot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TestSpringBootStarterApplicationTests {

	@Test
	void contextLoads() {
	}

}
